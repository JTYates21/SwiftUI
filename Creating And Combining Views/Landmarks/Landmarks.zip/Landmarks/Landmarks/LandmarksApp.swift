//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by Jacek Yates on 4/5/22.
//

import SwiftUI

@main
struct LandmarksApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
